-- Databricks notebook source
-- Ingesting data from landing container to bronze layer streaming table fact_transactions_bronze

CREATE OR REFRESH STREAMING TABLE fact_transactions_bronze
Location 'abfss://bronze@kafkagen2stg.dfs.core.windows.net/fact_transactions_bronze'
SELECT
  customer_id,
  month,
  category,
  payment_type,
  spend,
  transaction_id,
  _rescued_data,
  current_timestamp() as load_time
FROM cloud_files('abfss://landing@kafkagen2stg.dfs.core.windows.net/kafka_consumer_sink/',
                  'csv',
                  map('cloudFiles.inferSchema', 'true')
                  )

-- COMMAND ----------

-- Ingesting data from landing container to bronze layer streaming table dim_customer_bronze

CREATE OR REFRESH STREAMING TABLE dim_customer_bronze
Location 'abfss://bronze@kafkagen2stg.dfs.core.windows.net/dim_customer_bronze'
SELECT
  customer_id,
  age_group,
  city,
  occupation,
  gender,
  `marital status` AS marital_status,
  avg_income,
  _rescued_data,
  current_timestamp() as load_time
FROM cloud_files('abfss://landing@kafkagen2stg.dfs.core.windows.net/mysql/finance/',
                  'csv',
                  map('cloudFiles.inferSchema', 'true')
                  )

-- COMMAND ----------

-- Logging for the rescued data in dlt_bronze_rescued_data_log_tbl

CREATE OR REFRESH STREAMING TABLE dlt_bronze_rescued_data_log_tbl
LOCATION 'abfss://silver@kafkagen2stg.dfs.core.windows.net/dlt_bronze_rescued_data_log_tbl'
AS
SELECT
  'fact_transactions_bronze' as table_name,
  _rescued_data as rescued_data,
  load_time,
  'open' as issue_status
FROM
  STREAM(LIVE.fact_transactions_bronze)
WHERE
   _rescued_data IS NOT NULL
UNION ALL
SELECT
  'dim_transactions_bronze' as table_name,
  _rescued_data as rescued_data,
  load_time,
  'open' as issue_status
FROM
  STREAM(LIVE.dim_customer_bronze)
WHERE
   _rescued_data IS NOT NULL

-- COMMAND ----------

-- Ingesting data to silver layer from bronze layer streaming table fact_transactions_silver_temp

CREATE OR REFRESH STREAMING TABLE fact_transactions_silver_temp (
  CONSTRAINT customer_id_exists EXPECT (customer_id IS NOT NULL) ON VIOLATION DROP ROW
)
LOCATION 'abfss://silver@kafkagen2stg.dfs.core.windows.net/fact_transactions_silver_temp'
AS
SELECT
  customer_id,
  month AS transaction_month,
  category,
  payment_type,
  spend,
  transaction_id,
  load_time
FROM 
  STREAM(LIVE.fact_transactions_bronze)
WHERE
  _rescued_data IS NULL

-- COMMAND ----------

-- Ingesting data to silver layer from bronze layer streaming table dim_customer_silver_temp

CREATE OR REFRESH STREAMING TABLE dim_customer_silver_temp (
  CONSTRAINT customer_id_exists EXPECT (customer_id IS NOT NULL) ON VIOLATION DROP ROW
)
LOCATION 'abfss://silver@kafkagen2stg.dfs.core.windows.net/dim_customer_silver_temp'
AS
SELECT
  customer_id,
  age_group,
  city,
  occupation,
  gender,
  marital_status,
  avg_income,
  load_time
FROM 
  STREAM(LIVE.dim_customer_bronze)
WHERE
  _rescued_data IS NULL

-- COMMAND ----------

CREATE OR REFRESH STREAMING TABLE dim_customer_silver
LOCATION 'abfss://silver@kafkagen2stg.dfs.core.windows.net/dim_customer_silver';

APPLY CHANGES INTO LIVE.dim_customer_silver
FROM STREAM(LIVE.dim_customer_silver_temp)
KEYS (customer_id)
SEQUENCE BY load_time
STORED AS SCD TYPE 1;

-- COMMAND ----------

-- Ingesting data to silver layer from bronze layer streaming table fact_transactions_silver

CREATE OR REFRESH STREAMING TABLE fact_transactions_silver
LOCATION 'abfss://silver@kafkagen2stg.dfs.core.windows.net/fact_transactions_silver';

APPLY CHANGES INTO LIVE.fact_transactions_silver
FROM STREAM(LIVE.fact_transactions_silver_temp)
KEYS (transaction_id)
SEQUENCE BY load_time
STORED AS SCD TYPE 2;

-- COMMAND ----------

-- Total Spend by Customer's occupation and Gender
CREATE LIVE TABLE total_spend_by_occupation_gender
LOCATION 'abfss://gold@kafkagen2stg.dfs.core.windows.net/total_spend_by_occupation_gender'
SELECT 
  d.occupation,
  d.gender,
  SUM(f.spend) as total_spend
FROM LIVE.fact_transactions_silver f
JOIN LIVE.dim_customer_silver d 
ON f.customer_id = d.customer_id
GROUP BY d.occupation, d.gender
ORDER BY d.occupation, d.gender;


-- COMMAND ----------

-- Average Spend by Customer's age group
CREATE LIVE TABLE avg_spend_by_age_group
LOCATION 'abfss://gold@kafkagen2stg.dfs.core.windows.net/avg_spend_by_age_group'
SELECT 
  d.age_group,
  AVG(f.spend) as avg_spend
FROM LIVE.fact_transactions_silver f
JOIN LIVE.dim_customer_silver d 
ON f.customer_id = d.customer_id
GROUP BY d.age_group
ORDER BY d.age_group;

-- COMMAND ----------

-- Customer distribution by city and transaction category
CREATE LIVE TABLE customer_distribution_by_city_and_category
LOCATION 'abfss://gold@kafkagen2stg.dfs.core.windows.net/customer_distribution_by_city_and_category'
SELECT
  d.city,
  f.category,
  COUNT(DISTINCT f.customer_id) as customer_count
FROM LIVE.fact_transactions_silver f
JOIN LIVE.dim_customer_silver d 
ON f.customer_id = d.customer_id
GROUP BY d.city, f.category
ORDER BY d.city, f.category;

-- COMMAND ----------

-- Creating materialized view for gold layer